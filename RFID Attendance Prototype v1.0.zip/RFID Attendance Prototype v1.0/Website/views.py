from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, current_user
from . import db
from .models import User, Attendance, Profiles
from .auth import check_password_hash, generate_password_hash
import datetime
from datetime import datetime

views = Blueprint('views', __name__)

@views.route('/')
@login_required
def home():
    username = current_user.username
    return render_template("home.html", user=current_user, username=username)



@views.route('/attendance', methods = ['GET', 'POST'])
@login_required
def attendance():
    received = request.form
    print(received)
    username = current_user.username
    data = Attendance.query.all()
    if request.method == 'POST':
        add_or_check = request.form.get('add_or_check')
        print(add_or_check)
        if add_or_check == 'check':
            input_id = request.form.get('employee_id')
            print(input_id)
            id_exist = Profiles.query.filter_by(id=input_id).first()
            if id_exist:
                msg = "Employee ID Found"
                now = datetime.now()
                name = id_exist.name
                date = now.strftime("%d-%m-%Y")
                time = now.strftime("%H:%M:%S")
                return render_template('add_attendance.html',user=current_user, employee_found=True, msg=msg, employee_id=input_id, name=name, date=date, time=time)
            else:
                flash("Employee ID NOT Found", category='error')
        elif add_or_check == 'add':
            id = request.form.get('employee_id')
            name = request.form.get('employee_name')
            date = request.form.get('date')
            time = request.form.get('time')
            status = request.form.get('status')
            print(id)
            print(name)
            print(date)
            print(time)
            print(status)
            new_attendance = Attendance(id=id, name=name, date=date, time=time, status=status)
            db.session.add(new_attendance)
            db.session.commit()
            flash('Added New Record of Attendance!', category='success')
            return redirect(url_for('views.attendance'))
    return render_template('attendance.html', attendance=data, user=current_user, username=username)

@views.route('/employee_list')
@login_required
def employee_list():
    username = current_user.username
    data = Profiles.query.all()
    return render_template('employee_list.html', employees=data, user=current_user, username=username)

@views.route('/account_settings', methods = ['GET', 'POST'])
@login_required
def account_settings():
    username = current_user.username
    name = current_user.name
    email = current_user.email
    password = current_user.password
    return render_template('account_settings.html', user=current_user, username=username, name=name, email=email, password=password)

@views.route('/change_password', methods = ['GET', 'POST'])
@login_required
def change_password():
    username = current_user.username
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password1 = request.form.get('new_password1')
        new_password2 = request.form.get('new_password2')
        userpasswordhash = current_user.password
        if not check_password_hash(userpasswordhash, current_password):
            flash('Password Incorrect',category='error')
        elif len(new_password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        elif new_password1 != new_password2:
            flash("New passwords don't match.",category='error')
        else:
            current_user.password = generate_password_hash(new_password1,method='SHA256')
            db.session.commit()
            flash("Successfully changed password.",category='success')
            return redirect(url_for('views.account_settings'))
    return render_template('change_password.html', user=current_user, username=username)

